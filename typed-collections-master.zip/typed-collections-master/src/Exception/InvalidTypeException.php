<?php
namespace Phpsafari\Exception;

use Exception;

class InvalidTypeException extends Exception
{

}
