<?php

namespace Phpsafari\Collections;

use Phpsafari\Example\User;

class UserCollection extends TypedCollection
{
    protected $type = User::class;
}
